Steps to Run:

1. pip install GitPython
2. Paste the repo link in the app.py file at REPO_URL.
3. Run command on terminal "python app.py"